<?php
// ============================================================
// MALZ-FLIX - VIDEO.PHP (TANPA RATE LIMIT + XPass & VidLink)
// ============================================================
$movie_id = isset($_GET['id']) ? (int)$_GET['id'] : 550;
$selected_source = isset($_GET['source']) ? (int)$_GET['source'] : 0;

// ============================================================
// SOURCES (HANYA 2 SERVER: XPass + VidLink)
// ============================================================
$sources = [
    ['name' => 'XPass', 'url' => "https://play.xpass.top/e/movie/{$movie_id}"],
    ['name' => 'VidLink', 'url' => "https://vidlink.pro/movie/{$movie_id}"],
];

if (isset($_GET['source']) && is_numeric($_GET['source']) && $_GET['source'] < count($sources)) {
    $selected_source = (int)$_GET['source'];
}

$video_url = $sources[$selected_source]['url'];
$source_name = $sources[$selected_source]['name'];

$tmdb_key = '5a61a8e1df2f614dc83609925720c35d';
$movie_data = @file_get_contents("https://api.themoviedb.org/3/movie/{$movie_id}?api_key={$tmdb_key}&language=id-ID");
$movie = $movie_data ? json_decode($movie_data, true) : null;
$title = $movie['title'] ?? 'Film';
$poster = $movie['poster_path'] ? "https://image.tmdb.org/t/p/w500" . $movie['poster_path'] : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title>Malz-Flix | <?php echo htmlspecialchars($title); ?></title>
    <link rel="icon" type="image/png" href="/images/logo-web.png">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0a0f;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            padding: 16px 24px;
            background: rgba(10,10,15,0.8);
            backdrop-filter: blur(16px);
            border-bottom: 1px solid rgba(255,255,255,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .header a { 
            color: rgba(255,255,255,0.6); 
            text-decoration: none; 
            font-size: 14px; 
            font-weight: 600; 
            transition: color 0.3s;
            padding: 8px 12px;
            border-radius: 8px;
            cursor: pointer;
        }
        .header a:hover { 
            color: #fff; 
            background: rgba(255,255,255,0.05);
        }
        .header-left { display: flex; align-items: center; gap: 16px; }
        .header-right { display: flex; align-items: center; gap: 16px; }
        .header h1 { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
        .header h1 span { color: #fff; }
        .header .menu-icon {
            cursor: pointer;
            font-size: 24px;
            color: rgba(255,255,255,0.6);
            padding: 4px 8px;
            border-radius: 8px;
            transition: all 0.3s;
            user-select: none;
        }
        .header .menu-icon:hover {
            color: #fff;
            background: rgba(255,255,255,0.05);
        }
        .player-wrapper {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: #000;
            position: relative;
        }
        .player-wrapper iframe {
            width: 100%;
            max-width: 1200px;
            height: 80vh;
            border: none;
            border-radius: 12px;
            background: #0a0a0f;
            box-shadow: 0 20px 60px rgba(0,0,0,0.8);
        }
        .info-bar {
            padding: 16px 24px;
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(12px);
            border-top: 1px solid rgba(255,255,255,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .info-bar .title { font-size: 18px; font-weight: 700; }
        .info-bar .source { font-size: 12px; color: rgba(255,255,255,0.4); }
        .source-selector { display: flex; gap: 8px; flex-wrap: wrap; }
        .source-btn {
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.08);
            color: rgba(255,255,255,0.5);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 11px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
        }
        .source-btn:hover { background: rgba(255,255,255,0.12); color: #fff; }
        .source-btn.active { background: #fff; color: #000; border-color: #fff; }
        iframe[src*="googleads"], iframe[src*="doubleclick"] { display: none !important; }
        @media (max-width: 768px) {
            .header { padding: 12px 16px; }
            .header h1 { font-size: 16px; }
            .header a { font-size: 12px; padding: 6px 10px; }
            .player-wrapper iframe { height: 50vh; }
            .info-bar .title { font-size: 15px; }
            .source-btn { font-size: 10px; padding: 4px 10px; }
            .header .menu-icon { font-size: 20px; }
        }
        @media (max-width: 480px) {
            .player-wrapper iframe { height: 40vh; }
            .info-bar { flex-direction: column; align-items: flex-start; }
            .header { flex-wrap: wrap; gap: 8px; }
            .header-left { flex: 1; }
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="header-left">
            <span class="menu-icon" id="menuToggle">☰</span>
            <a href="/Netflix/">← Kembali</a>
            <h1>🎬 <span>Ziqin-Flix</span></h1>
        </div>
        <div class="header-right">
            <a href="/">🏠 Beranda</a>
        </div>
    </div>

    <div class="player-wrapper">
        <iframe src="<?php echo htmlspecialchars($video_url); ?>" 
                allowfullscreen 
                allow="autoplay; encrypted-media; fullscreen"
                loading="lazy"
                id="playerIframe">
        </iframe>
    </div>

    <div class="info-bar">
        <div>
            <div class="title"><?php echo htmlspecialchars($title); ?></div>
            <div class="source">Sumber: <?php echo htmlspecialchars($source_name); ?></div>
        </div>
        <div class="source-selector">
            <?php foreach ($sources as $i => $src): ?>
            <a href="?id=<?php echo $movie_id; ?>&source=<?php echo $i; ?>" 
               class="source-btn <?php echo $i == $selected_source ? 'active' : ''; ?>">
                <?php echo $src['name']; ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        // ============================================================
        // NAVBAR - FIX BAR KIRI BISA DI KLIK
        // ============================================================
        document.getElementById('menuToggle').addEventListener('click', function(e) {
            e.stopPropagation();
            alert('📋 Ziqin-Flix Menu\n\n← Kembali ke halaman utama\n🏠 Beranda utama website');
        });

        // ============================================================
        // ANTI-CLICKJAKING + BLOCK ADS + TOLAK POPUP DARI IFRAME
        // ============================================================
        (function() {
            // Block window.open (popup dari iframe)
            const originalOpen = window.open;
            window.open = function(url, name, specs) {
                if (url) {
                    console.log('[Security] Blocked popup:', url);
                    return null;
                }
                return originalOpen.call(this, url, name, specs);
            };
            
            // Block redirect
            const originalLocation = Object.getOwnPropertyDescriptor(window, 'location');
            Object.defineProperty(window, 'location', {
                set: function(value) {
                    if (typeof value === 'string') {
                        console.log('[Security] Blocked redirect:', value);
                        return;
                    }
                    originalLocation.set.call(this, value);
                },
                get: function() { return originalLocation.get.call(this); }
            });
            
            // Block postMessage dari iframe
            window.addEventListener('message', function(e) {
                console.log('[Security] Blocked postMessage:', e.data);
                e.stopPropagation();
                e.preventDefault();
                return false;
            }, true);
            
            // Block iframe injection
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.tagName === 'IFRAME') {
                            const src = node.src || '';
                            if (src.includes('googleads') || src.includes('doubleclick') || src.includes('adservice') || src.includes('popup')) {
                                node.remove();
                                console.log('[Security] Removed ad iframe:', src);
                            }
                        }
                        if (node.tagName === 'SCRIPT' && node.src) {
                            const src = node.src || '';
                            if (src.includes('googleads') || src.includes('doubleclick') || src.includes('popup')) {
                                node.remove();
                                console.log('[Security] Removed ad script:', src);
                            }
                        }
                    });
                });
            });
            observer.observe(document.body, { childList: true, subtree: true });
            
            console.log('[Security] Anti-popup + Anti-clickjaking aktif ✅');
        })();

        // ============================================================
        // AUTO SWITCH SOURCE JIKA IFRAME GAGAL
        // ============================================================
        const iframe = document.getElementById('playerIframe');
        let sourceIndex = <?php echo $selected_source; ?>;
        const totalSources = <?php echo count($sources); ?>;
        const movieId = <?php echo $movie_id; ?>;
        let attempts = 0;

        iframe.addEventListener('error', function() {
            attempts++;
            if (attempts < 3) {
                sourceIndex = (sourceIndex + 1) % totalSources;
                const sourceUrls = <?php echo json_encode(array_column($sources, 'url')); ?>;
                iframe.src = sourceUrls[sourceIndex];
                console.log('[Player] Switch ke sumber:', sourceIndex);
                const url = new URL(window.location);
                url.searchParams.set('source', sourceIndex);
                window.history.replaceState({}, '', url);
                const sourceNames = <?php echo json_encode(array_column($sources, 'name')); ?>;
                document.querySelector('.source').textContent = 'Sumber: ' + sourceNames[sourceIndex];
                document.querySelectorAll('.source-btn').forEach((btn, i) => {
                    btn.classList.toggle('active', i === sourceIndex);
                });
                document.cookie = 'malzflix_source=' + sourceIndex + '; path=/; max-age=2592000';
            }
        });

        // ============================================================
        // KEYBOARD SHORTCUT
        // ============================================================
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                window.location.href = '/Netflix/';
            }
            if (e.key === 'f' || e.key === 'F') {
                if (iframe.requestFullscreen) {
                    iframe.requestFullscreen();
                }
            }
        });

        console.log('🎬 Ziqin-Flix Player siap!');
        console.log('🔒 Security: Anti-popup + Anti-clickjaking + Auto-switch ✅');
        console.log('💡 Shortcut: ESC = kembali, F = fullscreen');
    </script>

</body>
</html>