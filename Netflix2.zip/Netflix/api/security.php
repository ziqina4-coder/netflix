<?php
// ============================================================
// MALZ-FLIX - SECURITY ENGINE
// ============================================================

function getClientIP() {
    $headers = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    foreach ($headers as $key) {
        if (isset($_SERVER[$key]) && $_SERVER[$key]) {
            $ip = $_SERVER[$key];
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
            }
            return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
        }
    }
    return '0.0.0.0';
}

function isWhitelisted($ip) {
    $whitelist = ['127.0.0.1', '::1', '103.112.244.90'];
    return in_array($ip, $whitelist);
}

function isBlocked($ip) {
    $log_file = __DIR__ . '/../logs/blocked_ips.json';
    if (!file_exists($log_file)) return false;
    
    $data = json_decode(file_get_contents($log_file), true);
    if (!isset($data[$ip])) return false;
    
    if ($data[$ip]['expires'] < time()) {
        unset($data[$ip]);
        file_put_contents($log_file, json_encode($data, JSON_PRETTY_PRINT));
        return false;
    }
    
    return true;
}

function blockIP($ip, $reason = 'Scraping / Crawling berlebihan') {
    $log_file = __DIR__ . '/../logs/blocked_ips.json';
    $data = [];
    if (file_exists($log_file)) {
        $data = json_decode(file_get_contents($log_file), true);
    }
    
    $data[$ip] = [
        'reason' => $reason,
        'expires' => time() + 3600,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    file_put_contents($log_file, json_encode($data, JSON_PRETTY_PRINT));
}

function logRequest($ip) {
    $log_dir = __DIR__ . '/../logs/';
    if (!is_dir($log_dir)) mkdir($log_dir, 0755, true);
    
    $log_file = $log_dir . 'requests.json';
    $data = [];
    if (file_exists($log_file)) {
        $data = json_decode(file_get_contents($log_file), true);
    }
    
    if (!isset($data[$ip])) {
        $data[$ip] = ['count' => 0, 'reset' => time() + 60];
    }
    
    if ($data[$ip]['reset'] < time()) {
        $data[$ip] = ['count' => 0, 'reset' => time() + 60];
    }
    
    $data[$ip]['count']++;
    file_put_contents($log_file, json_encode($data, JSON_PRETTY_PRINT));
    
    return $data[$ip]['count'];
}

function checkRequestLimit($ip) {
    $max_requests = 60;
    if (isWhitelisted($ip)) return true;
    if (isBlocked($ip)) return false;
    
    $count = logRequest($ip);
    if ($count > $max_requests) {
        blockIP($ip, 'Rate limit exceeded (' . $count . ' request per menit)');
        return false;
    }
    
    return true;
}

function showBlockedPage($ip, $reason = 'Scraping / Crawling') {
    header('HTTP/1.1 403 Forbidden');
    include __DIR__ . '/../blocked.html';
    exit;
}
?>