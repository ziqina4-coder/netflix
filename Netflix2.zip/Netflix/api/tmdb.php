<?php
// ============================================================
// MALZ-FLIX - TMDB PROXY (API KEY AMAN)
// ============================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: https://malz-official.biz.id');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// Include rate limiter
require_once __DIR__ . '/rate-limit.php';

$ip = getClientIP();
if (isBlocked($ip)) {
    http_response_code(403);
    echo json_encode(['error' => 'IP diblokir', 'ip' => $ip]);
    exit;
}

if (!checkRequestLimit($ip)) {
    blockIP($ip, 'Rate limit exceeded - TMDB API');
    http_response_code(429);
    echo json_encode(['error' => 'Too many requests', 'ip' => $ip]);
    exit;
}

// ============================================================
// KONFIGURASI
// ============================================================
$api_key = '5a61a8e1df2f614dc83609925720c35d';
$base_url = 'https://api.themoviedb.org/3';

$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';
$params = $_GET;

unset($params['endpoint']);
$params['api_key'] = $api_key;

if (!isset($params['language'])) {
    $params['language'] = 'id-ID';
}

if (empty($endpoint)) {
    http_response_code(400);
    echo json_encode(['error' => 'Endpoint required']);
    exit;
}

$url = $base_url . $endpoint . '?' . http_build_query($params);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'Malz-Flix/1.0');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

http_response_code($httpCode);
echo $response;
?>