<?php
// ============================================================
// MALZ-FLIX - INDEX.PHP (FULL FIX - SEARCH + PAGINATION + NAVBAR)
// ============================================================
$username = '';
$total_offline = 0;
$is_new_user = false;
$greeting = '';
$user_language = isset($_COOKIE['malzflix_lang']) ? $_COOKIE['malzflix_lang'] : 'id';
$show_login = isset($_GET['login']) || !isset($_COOKIE['malzflix_user']);

$language_map = [
    'id' => ['name' => 'Indonesia', 'flag' => '🇮🇩'],
    'ms' => ['name' => 'Malaysia', 'flag' => '🇲🇾'],
    'en' => ['name' => 'English', 'flag' => '🇬🇧']
];

if (isset($_COOKIE['malzflix_user'])) {
    $username = htmlspecialchars($_COOKIE['malzflix_user']);
    if (isset($_COOKIE['malzflix_last_active'])) {
        $last_active = (int)$_COOKIE['malzflix_last_active'];
        $offline_seconds = time() - $last_active;
        $total_offline = isset($_COOKIE['malzflix_total_offline']) ? (int)$_COOKIE['malzflix_total_offline'] + $offline_seconds : $offline_seconds;
        setcookie('malzflix_total_offline', $total_offline, time() + (86400 * 365), '/');
    }
    setcookie('malzflix_last_active', time(), time() + (86400 * 365), '/');
    $greeting = "Hai 👋 $username, selamat datang kembali!😘";
} else {
    $is_new_user = true;
    $greeting = 'Selamat datang! Sila masukkan username.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $input = trim($_POST['username']);
    if (!empty($input)) {
        setcookie('malzflix_user', $input, time() + (86400 * 365), '/');
        setcookie('malzflix_last_active', time(), time() + (86400 * 365), '/');
        setcookie('malzflix_total_offline', 0, time() + (86400 * 365), '/');
        if (isset($_POST['language'])) {
            setcookie('malzflix_lang', $_POST['language'], time() + (86400 * 365), '/');
        }
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    }
}

if (isset($_GET['lang']) && isset($language_map[$_GET['lang']])) {
    setcookie('malzflix_lang', $_GET['lang'], time() + (86400 * 365), '/');
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

if (isset($_GET['logout'])) {
    setcookie('malzflix_user', '', time() - 3600, '/');
    setcookie('malzflix_last_active', '', time() - 3600, '/');
    setcookie('malzflix_total_offline', '', time() - 3600, '/');
    setcookie('malzflix_lang', '', time() - 3600, '/');
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

function formatOfflineTime($seconds) {
    if ($seconds < 60) return $seconds . ' saat';
    if ($seconds < 3600) return floor($seconds / 60) . ' minit';
    if ($seconds < 86400) return floor($seconds / 3600) . ' jam';
    return floor($seconds / 86400) . ' hari';
}
?>
<!DOCTYPE html>
<html class="dark" lang="<?php echo $user_language; ?>">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Malz-Flix | Streaming Tanpa Iklan</title>
    <link rel="icon" type="image/png" href="/images/logo-web.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#ffffff",
                        "surface": "#121414",
                        "background": "#121414",
                        "on-surface": "#e3e2e2",
                        "on-surface-variant": "#c4c7c8",
                        "on-primary": "#2f3131"
                    },
                    borderRadius: { "full": "9999px", "xl": "1.5rem" },
                    spacing: {
                        "margin-desktop": "64px",
                        "margin-mobile": "20px",
                        "gutter": "24px"
                    },
                    fontFamily: { "label-caps": ["Inter"], "headline-xl": ["Inter"] },
                    fontSize: {
                        "label-caps": ["12px", { "letterSpacing": "1px", "fontWeight": "600" }],
                        "headline-xl": ["64px", { "letterSpacing": "-1.5px", "fontWeight": "700" }]
                    }
                }
            }
        }
    </script>
    <style>
        .glass-panel { backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
        .movie-card-glow:hover { box-shadow: 0 10px 25px -5px rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.3); }
        #userGreeting { transition: all 0.3s ease; }
        #userGreeting:hover { border-color: rgba(255,255,255,0.2); }
        .btn-play { background: linear-gradient(135deg, #ffffff 0%, #cccccc 100%); color: #000; font-weight: 800; padding: 16px 48px; border-radius: 60px; font-size: 18px; transition: all 0.3s ease; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 12px; box-shadow: 0 8px 30px rgba(255,255,255,0.15); }
        .btn-play:hover { transform: scale(1.05); box-shadow: 0 12px 40px rgba(255,255,255,0.25); }
        [class*="google_ads"],[class*="adsbygoogle"],[id*="google_ads"],[id*="adsbygoogle"],.ad-container,.ad-banner,.ad-wrapper,.ad-slot,.ad-unit,iframe[src*="doubleclick"],iframe[src*="googleads"],iframe[src*="googlesyndication"],iframe[src*="adservice"],iframe[src*="adserver"],iframe[src*="adsystem"],[class*="ad_"],[id*="ad_"],[class*="ads_"],[id*="ads_"],[data-ad],[data-ad-client],[data-ad-slot],[data-ad-unit],.advertisement,.advertising,.advert,.sponsored,.banner-ad,.banner_ads,.banner-ads,iframe[src*="popup"],iframe[src*="popunder"],script[src*="googleads"],script[src*="googlesyndication"] { display: none !important; width: 0 !important; height: 0 !important; overflow: hidden !important; visibility: hidden !important; opacity: 0 !important; pointer-events: none !important; position: absolute !important; top: -9999px !important; left: -9999px !important; }
        *:has(> [class*="ad-"]), *:has(> [id*="ad-"]) { display: none !important; }
        .hero-text { color: rgba(255,255,255,0.7); font-size: 16px; line-height: 1.8; max-width: 600px; margin-bottom: 30px; }
        .login-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.92); backdrop-filter: blur(20px); z-index: 999; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .login-card { background: rgba(20,20,31,0.9); border: 1px solid rgba(255,255,255,0.08); border-radius: 28px; padding: 48px 40px; max-width: 420px; width: 100%; text-align: center; box-shadow: 0 40px 80px rgba(0,0,0,0.6); }
        .login-card h2 { font-size: 28px; font-weight: 800; color: #fff; margin-bottom: 8px; }
        .login-card p { color: rgba(255,255,255,0.4); font-size: 14px; margin-bottom: 24px; }
        .login-card input { width: 100%; padding: 14px 18px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); border-radius: 60px; color: #fff; font-size: 16px; outline: none; transition: border 0.3s; margin-bottom: 12px; }
        .login-card input:focus { border-color: rgba(255,255,255,0.3); }
        .login-card select { width: 100%; padding: 14px 18px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); border-radius: 60px; color: #fff; font-size: 16px; outline: none; margin-bottom: 16px; cursor: pointer; }
        .login-card select option { background: #1a1a2e; color: #fff; }
        .login-card button { width: 100%; padding: 14px; background: #fff; color: #000; border: none; border-radius: 60px; font-size: 16px; font-weight: 700; cursor: pointer; transition: all 0.3s; }
        .login-card button:hover { transform: scale(1.02); }
        .search-container { display: flex; gap: 10px; align-items: center; background: rgba(255,255,255,0.05); border-radius: 60px; padding: 4px; border: 1px solid rgba(255,255,255,0.08); }
        .search-container input { background: transparent; border: none; padding: 10px 16px; color: #fff; font-size: 14px; outline: none; width: 180px; }
        .search-container input::placeholder { color: rgba(255,255,255,0.4); }
        .search-container button { background: transparent; border: none; color: rgba(255,255,255,0.6); cursor: pointer; padding: 8px 14px; transition: color 0.3s; }
        .search-container button:hover { color: #fff; }
        .pagination { display: flex; justify-content: center; gap: 12px; margin-top: 30px; }
        .pagination button { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); color: rgba(255,255,255,0.6); padding: 8px 20px; border-radius: 30px; cursor: pointer; transition: all 0.3s; font-size: 13px; }
        .pagination button:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .pagination button:disabled { opacity: 0.3; cursor: not-allowed; }
        .menu-dropdown {
            position: fixed;
            top: 72px;
            left: 0;
            background: rgba(10,10,15,0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,255,255,0.05);
            border-right: 1px solid rgba(255,255,255,0.05);
            padding: 20px 24px;
            min-width: 260px;
            z-index: 200;
            display: none;
            border-radius: 0 0 16px 0;
            box-shadow: 0 20px 60px rgba(0,0,0,0.8);
        }
        .menu-dropdown.open { display: block; animation: slideDown 0.2s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .menu-dropdown a, .menu-dropdown .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: 10px;
            color: rgba(255,255,255,0.6);
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s;
            cursor: pointer;
            border: none;
            background: transparent;
            width: 100%;
        }
        .menu-dropdown a:hover, .menu-dropdown .menu-item:hover {
            background: rgba(255,255,255,0.05);
            color: #fff;
        }
        .menu-dropdown .divider {
            height: 1px;
            background: rgba(255,255,255,0.05);
            margin: 6px 0;
        }
        .menu-dropdown .menu-title {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255,255,255,0.2);
            padding: 8px 12px;
        }
        @media (max-width: 768px) {
            #userGreeting { top: 80px; right: 10px; max-width: 200px; padding: 12px 16px; }
            .btn-play { padding: 14px 28px; font-size: 15px; width: 100%; justify-content: center; }
            .login-card { padding: 32px 24px; }
            .hero-text { font-size: 14px; }
            .search-container input { width: 120px; }
        }
        @media (max-width: 480px) { .movie-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 12px !important; } }
    </style>
</head>
<body class="bg-background text-on-surface select-none">

<?php if ($is_new_user || isset($_GET['login'])): ?>
<div class="login-overlay" id="loginOverlay">
    <div class="login-card">
        <div style="font-size:48px;margin-bottom:12px;">🎬</div>
        <h2>Malz-Flix</h2>
        <p>Selamat datang! Sila masukkan username untuk mula.</p>
        <form method="POST" id="loginForm">
            <input type="text" name="username" placeholder="Username anda..." required autofocus>
            <select name="language">
                <option value="id">🇮🇩 Indonesia</option>
                <option value="ms" selected>🇲🇾 Malaysia</option>
                <option value="en">🇬🇧 English</option>
            </select>
            <button type="submit">🚀 Mula Menonton</button>
        </form>
        <p style="margin-top:16px;font-size:11px;color:rgba(255,255,255,0.2);">Cookies akan menyimpan username anda.</p>
    </div>
</div>
<?php endif; ?>

<!-- ===== MENU DROPDOWN ===== -->
<div class="menu-dropdown" id="menuDropdown">
    <div class="menu-title">Navigasi</div>
    <a href="/Netflix/"><span class="material-symbols-outlined">home</span> Beranda Netflix</a>
    <a href="/"><span class="material-symbols-outlined">public</span> Website Utama</a>
    <div class="divider"></div>
    <div class="menu-title">Tools Malz</div>
    <a href="/u/upload.php"><span class="material-symbols-outlined">upload</span> Malz Deploy</a>
    <a href="/slf/"><span class="material-symbols-outlined">link</span> SFL Bypass</a>
    <a href="/portfolio/"><span class="material-symbols-outlined">person</span> Portfolio</a>
    <div class="divider"></div>
    <div class="menu-title">Lain-lain</div>
    <?php if (!$is_new_user): ?>
    <a href="?logout=1" class="menu-item" style="color:#ff6b6b;">
        <span class="material-symbols-outlined">logout</span> Logout
    </a>
    <?php endif; ?>
</div>

<!-- USER GREETING -->
<div class="fixed top-20 right-4 z-40 bg-surface/80 backdrop-blur-xl border border-white/10 rounded-2xl px-5 py-3 max-w-xs shadow-2xl" id="userGreeting">
    <?php if (!$is_new_user && !isset($_GET['login'])): ?>
    <div class="flex items-center justify-between gap-4">
        <div>
            <p class="text-sm font-bold text-white"><?php echo $greeting; ?></p>
            <div class="flex gap-3 text-[10px] text-on-surface-variant/50">
                <span>🌎 <?php echo $language_map[$user_language]['flag'] ?? '🇮🇩'; ?></span>
                <?php if ($total_offline > 0): ?>
                <span>⏱ <?php echo formatOfflineTime($total_offline); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="flex gap-2">
            <a href="?lang=id" class="text-[10px] text-on-surface-variant/40 hover:text-white transition">🇮🇩</a>
            <a href="?lang=ms" class="text-[10px] text-on-surface-variant/40 hover:text-white transition">🇲🇾</a>
            <a href="?lang=en" class="text-[10px] text-on-surface-variant/40 hover:text-white transition">🇬🇧</a>
            <a href="?logout=1" class="text-[10px] text-on-surface-variant/40 hover:text-white transition ml-1">Logout</a>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- HEADER -->
<header class="fixed top-0 w-full z-50 bg-surface/60 backdrop-blur-3xl border-b border-white/10 flex items-center justify-between px-margin-mobile md:px-margin-desktop h-20 transition-all duration-300" id="mainHeader">
    <div class="flex items-center gap-6">
        <span class="material-symbols-outlined cursor-pointer text-primary" id="menuToggle" style="padding:8px 12px;border-radius:8px;transition:all 0.3s;">menu</span>
        <h1 class="font-headline-md text-headline-md font-bold tracking-tighter text-primary">ZIQINFLIX</h1>
    </div>
    <nav class="hidden md:flex items-center gap-10">
        <a class="text-primary border-b border-primary pb-1 font-label-caps text-label-caps" href="#" id="navHome">BERANDA</a>
        <a class="text-on-surface-variant font-label-caps text-label-caps hover:text-primary transition-colors" href="#" id="navPopular">POPULER</a>
        <a class="text-on-surface-variant font-label-caps text-label-caps hover:text-primary transition-colors" href="#" id="navTopRated">RATING TERTINGGI</a>
        <a class="text-on-surface-variant font-label-caps text-label-caps hover:text-primary transition-colors" href="#" id="navUpcoming">AKAN DATANG</a>
    </nav>
    <div class="flex items-center gap-4">
        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Cari film..." />
            <button id="searchBtn">🔍</button>
        </div>
        <div class="w-8 h-8 rounded-full border border-white/20 bg-surface-container overflow-hidden hidden md:block">
            <img class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCBkhwFMTZPoMwMBm2k1RvS-E-iUkYtm7DJ64a1vHJSOdrA38gsZ7o0y4wD8X2k5zFqk_q-M6ui7IoUF9aCH1HjL-F6AHh5CKnit3NpnRT_pIs0kinwpZXNEl0YgW0LmaLUVQ9hxcx6Laa3lqT6t4IdXHLWbKXu36_ID0CulWJz3j65qCZz8ENIllzg_ueClLcF-nn-1KhRfg3b0UY4yo_r9UanNE86tgFc52aFtiyg8kMzK43gUTw" alt="Profile"/>
        </div>
    </div>
</header>

<!-- MAIN -->
<main class="pb-32">
    <section class="relative h-[751px] w-full overflow-hidden" id="heroSection">
        <div class="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-transparent z-10"></div>
        <div class="absolute inset-0 w-full h-full scale-105 animate-[pulse_8s_ease-in-out_infinite]">
            <div class="w-full h-full bg-cover bg-center brightness-75" style="background-image: url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1025&auto=format&fit=crop')"></div>
        </div>
        <div class="relative z-20 h-full flex flex-col justify-end px-margin-mobile md:px-margin-desktop pb-24 max-w-4xl">
            <p class="font-label-caps text-label-caps tracking-[0.2em] text-primary mb-4">SEDANG TAYANG</p>
            <h2 class="font-headline-xl text-headline-xl md:text-[80px] mb-6 leading-none">Malz-Flix</h2>
            <div class="hero-text">
                Streaming film gratis tanpa iklan. Koleksi terbaik dari seluruh dunia.<br>
                Kami menyediakan puluhan video sama seperti Netflix tanpa meletakkan 1 pun iklan dan tiada jenis jenis malware atau clickjaking kerana kami tidak mengambil keuntungan ~Malz
            </div>
            <div class="flex flex-wrap gap-4">
                <button class="btn-play" id="heroPlayBtn">
                    <span class="material-symbols-outlined" style="font-variation-settings:'FILL'1;">play_arrow</span>
                    Malz-Flix
                </button>
                <button class="border border-white/30 text-primary px-10 py-3.5 rounded-full font-label-caps text-label-caps flex items-center gap-2 hover:bg-white/10 transition" id="heroInfoBtn">
                    <span class="material-symbols-outlined">info</span>
                    INFO
                </button>
            </div>
        </div>
    </section>

    <div class="px-margin-mobile md:px-margin-desktop space-y-20 -mt-10 relative z-30">
        <section>
            <div class="flex items-center justify-between mb-8">
                <h3 class="font-label-caps text-label-caps tracking-[0.3em] text-primary" id="sectionTitle">POPULER</h3>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-gutter" id="movieGrid">
                <div class="col-span-full text-center py-10 text-on-surface-variant/50">Memuat...</div>
            </div>
            <div class="pagination" id="pagination">
                <button id="prevPage" disabled>◀ Sebelumnya</button>
                <span id="pageInfo" style="color:rgba(255,255,255,0.4);font-size:14px;">Halaman 1</span>
                <button id="nextPage">Berikutnya ▶</button>
            </div>
        </section>
    </div>
</main>

<!-- FOOTER -->
<footer class="w-full py-16 border-t border-white/5 bg-background flex flex-col md:flex-row justify-between items-center px-margin-mobile md:px-margin-desktop gap-stack-md text-on-surface-variant">
    <div class="flex flex-col items-center md:items-start gap-2">
        <h1 class="font-headline-md text-headline-md text-primary font-bold tracking-tighter">MALZFLIX</h1>
        <p class="font-label-caps text-label-caps text-[10px]">© 2026 MALZFLIX. HAK CIPTA DILINDUNGI.</p>
    </div>
    <div class="flex gap-8 font-label-caps text-label-caps text-[10px]">
        <a class="hover:text-primary transition-colors" href="#">ATRIBUSI TMDB</a>
        <a class="hover:text-primary transition-colors" href="#">PRIVASI</a>
        <a class="hover:text-primary transition-colors" href="#">SYARAT</a>
    </div>
</footer>

<script>
// ============================================================
// MENU DROPDOWN TOGGLE
// ============================================================
const menuToggle = document.getElementById('menuToggle');
const menuDropdown = document.getElementById('menuDropdown');

menuToggle.addEventListener('click', function(e) {
    e.stopPropagation();
    menuDropdown.classList.toggle('open');
});

// Tutup menu klik di luar
document.addEventListener('click', function(e) {
    if (!menuDropdown.contains(e.target) && e.target !== menuToggle) {
        menuDropdown.classList.remove('open');
    }
});

// ============================================================
// STATE
// ============================================================
let currentPage = 1;
let currentCategory = 'popular';
let searchQuery = '';
let isSearch = false;

// ============================================================
// LOAD MOVIES
// ============================================================
async function loadMovies(page = 1, category = 'popular', query = '') {
    const grid = document.getElementById('movieGrid');
    const title = document.getElementById('sectionTitle');
    grid.innerHTML = '<div class="col-span-full text-center py-10 text-on-surface-variant/50">Memuat...</div>';

    let endpoint = '/movie/' + category;
    let params = { page: page };

    if (query) {
        endpoint = '/search/movie';
        params.query = query;
        title.textContent = 'HASIL PENCARIAN: ' + query;
    } else {
        const labels = {
            popular: 'POPULER',
            top_rated: 'RATING TERTINGGI',
            upcoming: 'AKAN DATANG',
            now_playing: 'SEDANG TAYANG'
        };
        title.textContent = labels[category] || 'POPULER';
    }

    try {
        const url = new URL('/Netflix/api/tmdb.php', window.location.origin);
        url.searchParams.set('endpoint', endpoint);
        Object.keys(params).forEach(key => url.searchParams.set(key, params[key]));
        const res = await fetch(url);
        const data = await res.json();

        if (data.results && data.results.length > 0) {
            grid.innerHTML = data.results.map(movie => {
                const poster = movie.poster_path ? 'https://image.tmdb.org/t/p/w500' + movie.poster_path : '';
                const title = movie.title || 'Unknown';
                const year = movie.release_date ? movie.release_date.substring(0,4) : 'TBA';
                const rating = movie.vote_average ? movie.vote_average.toFixed(1) : '?';
                return `
                <div class="movie-card group cursor-pointer transition-all duration-500 hover:translate-y-[-8px]" data-id="${movie.id}">
                    <div class="aspect-[2/3] relative overflow-hidden border border-white/10 rounded-xl movie-card-glow transition-all duration-500 mb-4 bg-surface-container">
                        <img src="${poster}" alt="${title}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" onerror="this.style.display='none'">
                        <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                            <div class="flex items-center gap-1 text-primary text-[10px] font-bold">
                                <span class="material-symbols-outlined text-sm">star</span>
                                ${rating}
                            </div>
                        </div>
                    </div>
                    <h4 class="font-label-caps text-[11px] text-primary tracking-wider truncate px-1">${title}</h4>
                    <div class="flex justify-between items-center mt-1 px-1">
                        <p class="text-[10px] text-on-surface-variant/50">${year}</p>
                        <p class="text-[10px] text-on-surface-variant/50 tracking-tighter">☆ ${rating}</p>
                    </div>
                </div>`;
            }).join('');

            grid.querySelectorAll('.movie-card').forEach(card => {
                card.addEventListener('click', () => {
                    window.location.href = '/Netflix/video.php?id=' + card.dataset.id;
                });
            });

            document.getElementById('pageInfo').textContent = 'Halaman ' + page;
            document.getElementById('prevPage').disabled = page <= 1;
            document.getElementById('nextPage').disabled = !data.results || data.results.length < 20;
        } else {
            grid.innerHTML = '<div class="col-span-full text-center py-10 text-on-surface-variant/50">Tiada filem ditemui.</div>';
        }
    } catch(e) {
        console.error(e);
        grid.innerHTML = '<div class="col-span-full text-center py-10 text-on-surface-variant/50">Gagal memuat filem.</div>';
    }
}

// ============================================================
// NAVIGATION
// ============================================================
document.getElementById('navHome').addEventListener('click', (e) => {
    e.preventDefault();
    currentCategory = 'popular';
    searchQuery = '';
    isSearch = false;
    document.getElementById('searchInput').value = '';
    currentPage = 1;
    loadMovies(currentPage, currentCategory);
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.getElementById('navPopular').addEventListener('click', (e) => {
    e.preventDefault();
    currentCategory = 'popular';
    searchQuery = '';
    isSearch = false;
    document.getElementById('searchInput').value = '';
    currentPage = 1;
    loadMovies(currentPage, currentCategory);
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.getElementById('navTopRated').addEventListener('click', (e) => {
    e.preventDefault();
    currentCategory = 'top_rated';
    searchQuery = '';
    isSearch = false;
    document.getElementById('searchInput').value = '';
    currentPage = 1;
    loadMovies(currentPage, currentCategory);
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.getElementById('navUpcoming').addEventListener('click', (e) => {
    e.preventDefault();
    currentCategory = 'upcoming';
    searchQuery = '';
    isSearch = false;
    document.getElementById('searchInput').value = '';
    currentPage = 1;
    loadMovies(currentPage, currentCategory);
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ============================================================
// SEARCH
// ============================================================
document.getElementById('searchBtn').addEventListener('click', () => {
    const query = document.getElementById('searchInput').value.trim();
    if (query) {
        searchQuery = query;
        isSearch = true;
        currentPage = 1;
        loadMovies(currentPage, 'popular', query);
    }
});

document.getElementById('searchInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        document.getElementById('searchBtn').click();
    }
});

// ============================================================
// PAGINATION
// ============================================================
document.getElementById('prevPage').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        if (isSearch) {
            loadMovies(currentPage, 'popular', searchQuery);
        } else {
            loadMovies(currentPage, currentCategory);
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
});

document.getElementById('nextPage').addEventListener('click', () => {
    currentPage++;
    if (isSearch) {
        loadMovies(currentPage, 'popular', searchQuery);
    } else {
        loadMovies(currentPage, currentCategory);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ============================================================
// HERO PLAY
// ============================================================
document.getElementById('heroPlayBtn').addEventListener('click', () => {
    const firstCard = document.querySelector('.movie-card');
    if (firstCard) {
        window.location.href = '/Netflix/video.php?id=' + firstCard.dataset.id;
    } else {
        window.location.href = '/Netflix/video.php?id=550';
    }
});

// ============================================================
// HEADER SCROLL
// ============================================================
let lastScroll = 0;
const header = document.getElementById('mainHeader');
window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    if (currentScroll > 50) {
        header.classList.add('bg-black/80', 'h-16');
        header.classList.remove('h-20');
    } else {
        header.classList.remove('bg-black/80', 'h-16');
        header.classList.add('h-20');
    }
    lastScroll = currentScroll;
});

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    loadMovies(1, 'popular');
    console.log('🎬 Ziqin-Flix siap!');
});

// ============================================================
// ADBLOCKER
// ============================================================
(function() {
    const blockedDomains = ['googleads','googlesyndication','doubleclick','adservice','adsystem','adserver','adnxs','criteo','taboola','outbrain','mgid','popads','popcash','propellerads','revcontent','content.ad','exoclick'];
    const origFetch = window.fetch;
    window.fetch = function(url, options) {
        if (typeof url === 'string') {
            for (const domain of blockedDomains) {
                if (url.includes(domain)) { console.log('[AdBlock] Blocked:', url); return Promise.reject(new Error('AdBlock')); }
            }
        }
        return origFetch.call(this, url, options);
    };
    const origXHR = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
        if (typeof url === 'string') {
            for (const domain of blockedDomains) {
                if (url.includes(domain)) { console.log('[AdBlock] Blocked XHR:', url); return; }
            }
        }
        return origXHR.call(this, method, url, async !== false, user, password);
    };
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('iframe, script').forEach(el => {
            const src = el.src || '';
            for (const domain of blockedDomains) {
                if (src.includes(domain)) el.remove();
            }
        });
    });
    console.log('[AdBlock] Malz-Flix AdBlocker aktif ✅');
})();
</script>
</body>
</html>