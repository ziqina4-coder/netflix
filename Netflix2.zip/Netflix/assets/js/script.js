// ============================================================
// ziqin-FLIX - SCRIPT.JS (TANPA RATE LIMIT + HANYA XPass & VidLink)
// ============================================================

// ============================================================
// KONFIGURASI
// ============================================================
const CONFIG = {
    TMDB_API_KEY: '5a61a8e1df2f614dc83609925720c35d',
    TMDB_BASE: 'https://api.themoviedb.org/3',
    IMAGE_BASE: 'https://image.tmdb.org/t/p/w500',
    IMAGE_ORIGINAL: 'https://image.tmdb.org/t/p/original',
    APP_NAME: 'Ziqin-Flix',
    TAGLINE: 'Cinema Unleashed — 100% Free Forever',
    API_PROXY: '/Netflix/api/tmdb.php'
};

// ============================================================
// DOM REFS
// ============================================================
const popularGrid = document.getElementById('popularGrid');
const heroPlayBtn = document.getElementById('heroPlayBtn');
const header = document.getElementById('mainHeader');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');

// ============================================================
// FETCH VIA PROXY
// ============================================================
async function fetchTMDB(endpoint, params = {}) {
    const url = new URL(CONFIG.API_PROXY, window.location.origin);
    url.searchParams.set('endpoint', endpoint);
    Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
            url.searchParams.set(key, params[key]);
        }
    });
    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('[TMDB] Error:', err);
        return null;
    }
}

// ============================================================
// RENDER MOVIE CARDS
// ============================================================
function renderMovies(container, movies, limit = 6) {
    if (!movies || movies.length === 0) {
        container.innerHTML = `<div class="col-span-full text-center py-10 text-on-surface-variant/50">Tidak ada film</div>`;
        return;
    }

    const items = movies.slice(0, limit);
    container.innerHTML = items.map(movie => {
        const poster = movie.poster_path ? CONFIG.IMAGE_BASE + movie.poster_path : '';
        const title = movie.title || movie.name || 'Unknown';
        const year = movie.release_date ? movie.release_date.substring(0, 4) : (movie.first_air_date ? movie.first_air_date.substring(0, 4) : 'TBA');
        const rating = movie.vote_average ? movie.vote_average.toFixed(1) : '?';
        const id = movie.id;

        return `
        <div class="movie-card group cursor-pointer transition-all duration-500 hover:translate-y-[-8px]" data-id="${id}">
            <div class="aspect-[2/3] relative overflow-hidden border border-white/10 rounded-xl movie-card-glow transition-all duration-500 mb-4 bg-surface-container">
                <img src="${poster}" alt="${title}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" onerror="this.style.display='none'">
                <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                    <div class="flex items-center gap-1 text-primary text-[10px] font-bold">
                        <span class="material-symbols-outlined text-sm">star</span>
                        ${rating}
                    </div>
                </div>
            </div>
            <h4 class="font-label-caps text-[11px] text-primary tracking-wider truncate px-1">${title}</h4>
            <div class="flex justify-between items-center mt-1 px-1">
                <p class="text-[10px] text-on-surface-variant/50">${year}</p>
                <p class="text-[10px] text-on-surface-variant/50 tracking-tighter">☆ ${rating}</p>
            </div>
        </div>`;
    }).join('');

    container.querySelectorAll('.movie-card').forEach(card => {
        card.addEventListener('click', () => {
            const id = card.dataset.id;
            window.location.href = `/Netflix/video.php?id=${id}`;
        });
    });
}

// ============================================================
// LOAD MOVIES BY CATEGORY
// ============================================================
async function loadMovies(page = 1, category = 'popular', query = '') {
    const grid = document.getElementById('movieGrid');
    const title = document.getElementById('sectionTitle');
    if (!grid) return;
    
    grid.innerHTML = '<div class="col-span-full text-center py-10 text-on-surface-variant/50">Memuat...</div>';

    let endpoint = '/movie/' + category;
    let params = { page: page };

    if (query) {
        endpoint = '/search/movie';
        params.query = query;
        title.textContent = 'HASIL PENCARIAN: ' + query;
    } else {
        const labels = {
            popular: 'POPULER',
            top_rated: 'RATING TERTINGGI',
            upcoming: 'AKAN DATANG',
            now_playing: 'SEDANG TAYANG'
        };
        title.textContent = labels[category] || 'POPULER';
    }

    try {
        const data = await fetchTMDB(endpoint, params);
        if (data && data.results && data.results.length > 0) {
            renderMovies(grid, data.results, 6);
            document.getElementById('pageInfo').textContent = 'Halaman ' + page;
            document.getElementById('prevPage').disabled = page <= 1;
            document.getElementById('nextPage').disabled = !data.results || data.results.length < 20;
        } else {
            grid.innerHTML = '<div class="col-span-full text-center py-10 text-on-surface-variant/50">Tiada filem ditemui.</div>';
        }
    } catch(e) {
        console.error(e);
        grid.innerHTML = '<div class="col-span-full text-center py-10 text-on-surface-variant/50">Gagal memuat filem.</div>';
    }
}

// ============================================================
// LOAD POPULAR MOVIES (DEFAULT)
// ============================================================
async function loadPopular() {
    if (!popularGrid) return;
    popularGrid.innerHTML = `<div class="col-span-full text-center py-10 text-on-surface-variant/50">Memuat...</div>`;
    const data = await fetchTMDB('/movie/popular', { page: 1 });
    if (data && data.results) {
        renderMovies(popularGrid, data.results, 6);
    }
}

// ============================================================
// HEADER SCROLL
// ============================================================
function initHeaderScroll() {
    if (!header) return;
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        if (currentScroll > 50) {
            header.classList.add('scrolled');
            header.style.backgroundColor = 'rgba(0,0,0,0.8)';
            header.style.height = '64px';
        } else {
            header.classList.remove('scrolled');
            header.style.backgroundColor = '';
            header.style.height = '';
        }
        lastScroll = currentScroll;
    });
}

// ============================================================
// HERO PLAY BUTTON
// ============================================================
function initHeroPlay() {
    if (!heroPlayBtn) return;
    heroPlayBtn.addEventListener('click', () => {
        const firstCard = document.querySelector('.movie-card');
        if (firstCard) {
            const id = firstCard.dataset.id;
            window.location.href = `/Netflix/video.php?id=${id}`;
        } else {
            window.location.href = '/Netflix/video.php?id=550';
        }
    });
}

// ============================================================
// SEARCH FUNCTION
// ============================================================
function initSearch() {
    if (!searchBtn || !searchInput) return;
    
    searchBtn.addEventListener('click', () => {
        const query = searchInput.value.trim();
        if (query) {
            document.getElementById('sectionTitle').textContent = 'HASIL PENCARIAN: ' + query;
            loadMovies(1, 'popular', query);
        }
    });

    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            searchBtn.click();
        }
    });
}

// ============================================================
// ADBLOCKER JS
// ============================================================
function initAdBlocker() {
    const blockedDomains = [
        'googleads', 'googlesyndication', 'doubleclick',
        'adservice', 'adsystem', 'adserver', 'adnxs',
        'criteo', 'taboola', 'outbrain', 'mgid',
        'popads', 'popcash', 'propellerads',
        'revcontent', 'content.ad', 'exoclick'
    ];

    const originalFetch = window.fetch;
    window.fetch = function(url, options) {
        if (typeof url === 'string') {
            for (const domain of blockedDomains) {
                if (url.includes(domain)) {
                    console.log('[AdBlock] Blocked fetch:', url);
                    return Promise.reject(new Error('AdBlock blocked'));
                }
            }
        }
        return originalFetch.call(this, url, options);
    };

    const originalXHROpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
        if (typeof url === 'string') {
            for (const domain of blockedDomains) {
                if (url.includes(domain)) {
                    console.log('[AdBlock] Blocked XHR:', url);
                    return;
                }
            }
        }
        return originalXHROpen.call(this, method, url, async !== false, user, password);
    };

    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('iframe, script').forEach(el => {
            const src = el.src || '';
            for (const domain of blockedDomains) {
                if (src.includes(domain)) {
                    el.remove();
                    console.log('[AdBlock] Removed element:', src);
                }
            }
        });
    });

    console.log('[AdBlock] Malz-Flix AdBlocker aktif ✅');
}

// ============================================================
// KEYBOARD SHORTCUTS
// ============================================================
function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl+K = focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            if (searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        }
    });
}

// ============================================================
// INIT ALL
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    loadPopular();
    initHeaderScroll();
    initHeroPlay();
    initSearch();
    initAdBlocker();
    initKeyboardShortcuts();
    console.log('🎬 ziqin-Flix siap!');
    console.log('🔒 Security: AdBlocker + Anti-clickjaking aktif ✅');
    console.log('💡 Shortcut: Ctrl+K untuk fokus search');
});